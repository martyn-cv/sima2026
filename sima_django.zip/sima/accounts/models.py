from django.conf import settings
from django.db import models


class Perfil(models.Model):
    TECNICO = "tecnico"
    INGENIERO = "ingeniero"
    OPERADOR = "operador"
    ROLES = [
        (TECNICO, "Técnico de mantenimiento"),
        (INGENIERO, "Ingeniero de mantenimiento"),
        (OPERADOR, "Operador de producción"),
    ]

    usuario = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="perfil")
    rol = models.CharField(max_length=20, choices=ROLES)
    nombre_visible = models.CharField(max_length=80, blank=True)

    def __str__(self):
        return f"{self.usuario.username} ({self.get_rol_display()})"

    @property
    def nombre(self):
        return self.nombre_visible or self.usuario.username
