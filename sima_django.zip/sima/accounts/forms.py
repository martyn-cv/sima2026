from django import forms
from django.conf import settings
from django.contrib.auth import authenticate


class LoginForm(forms.Form):
    email = forms.EmailField(
        label="Correo corporativo",
        widget=forms.EmailInput(attrs={"autocomplete": "username", "placeholder": f"usuario@{settings.DOMINIO_PERMITIDO}", "autofocus": True}),
    )
    password = forms.CharField(
        label="Contraseña",
        widget=forms.PasswordInput(attrs={"autocomplete": "current-password"}),
    )

    def __init__(self, *args, request=None, **kwargs):
        self.request = request
        self.user = None
        super().__init__(*args, **kwargs)

    def clean_email(self):
        email = self.cleaned_data["email"].strip().lower()
        if email.rsplit("@", 1)[-1] != settings.DOMINIO_PERMITIDO:
            raise forms.ValidationError(f"Solo se puede ingresar con un correo @{settings.DOMINIO_PERMITIDO}.")
        return email

    def clean(self):
        data = super().clean()
        email, password = data.get("email"), data.get("password")
        if email and password:
            user = authenticate(self.request, username=email, password=password)
            if user is None or not user.is_active or not hasattr(user, "perfil"):
                raise forms.ValidationError("Correo o contraseña incorrectos, o el usuario no tiene acceso a SIMA.")
            self.user = user
        return data
