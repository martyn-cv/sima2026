"""Carga los 3 usuarios autorizados y datos de ejemplo. Es idempotente."""
import os
from datetime import timedelta

from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand
from django.utils import timezone

from accounts.models import Perfil
from mantenimiento.models import (Bodega, BitacoraOT, Equipo, Informe, Nota, OrdenTrabajo, Plan,
                                  Repuesto, RepuestoOT, ReporteFalla, TipoRepuesto)

USUARIOS = [
    ("tecnico@manuandina.cl", Perfil.TECNICO, "Técnico de mantenimiento", "SIMA_PASSWORD_TECNICO", "Tecnico2026"),
    ("ingeniero@manuandina.cl", Perfil.INGENIERO, "Ingeniero de mantenimiento", "SIMA_PASSWORD_INGENIERO", "Ingeniero2026"),
    ("operador@manuandina.cl", Perfil.OPERADOR, "Operador de producción", "SIMA_PASSWORD_OPERADOR", "Operador2026"),
]


class Command(BaseCommand):
    help = "Crea los usuarios autorizados y datos de demostración."

    def handle(self, *args, **options):
        User = get_user_model()
        usuarios = {}
        for email, rol, nombre, var, por_defecto in USUARIOS:
            u, creado = User.objects.get_or_create(username=email, defaults={"email": email})
            if creado:
                u.set_password(os.environ.get(var, por_defecto))
                u.save()
            Perfil.objects.get_or_create(usuario=u, defaults={"rol": rol, "nombre_visible": nombre})
            usuarios[rol] = u
        tec, ing, ope = usuarios["tecnico"], usuarios["ingeniero"], usuarios["operador"]

        if Equipo.objects.exists():
            self.stdout.write("Datos de demostración ya cargados; solo se verificaron los usuarios.")
            return

        central = Bodega.objects.create(nombre="Bodega Central", ubicacion="Galpón 1, acceso norte")
        calderas = Bodega.objects.create(nombre="Bodega Calderas", ubicacion="Sala de calderas")
        electrica = Bodega.objects.create(nombre="Bodega Eléctrica", ubicacion="Taller eléctrico, 2º nivel")
        t = {n: TipoRepuesto.objects.create(nombre=n) for n in
             ["Rodamientos", "Sellos y empaquetaduras", "Eléctrico", "Hidráulico", "Resistencias", "Filtros"]}

        def rep(codigo, nombre, tipo, bodega, estante, stock, minimo, costo):
            return Repuesto.objects.create(codigo=codigo, nombre=nombre, tipo=t[tipo], bodega=bodega,
                                           estante=estante, stock=stock, stock_minimo=minimo, costo_unitario=costo)

        r_rod = rep("RP-0101", "Rodamiento 6208 2RS", "Rodamientos", central, "A-03", 12, 4, 8500)
        rep("RP-0102", "Rodamiento 22210 E", "Rodamientos", central, "A-04", 3, 4, 46000)
        r_sello = rep("RP-0201", "Kit de sellos cilindro hidráulico", "Sellos y empaquetaduras", central, "B-01", 5, 2, 38000)
        rep("RP-0202", "Empaquetadura bomba de agua", "Sellos y empaquetaduras", calderas, "C-02", 8, 3, 12500)
        r_res = rep("RP-0301", "Resistencia banda 220V 1200W", "Resistencias", electrica, "E-05", 2, 6, 24000)
        rep("RP-0302", "Contactor 3P 25A", "Eléctrico", electrica, "E-01", 9, 3, 21500)
        rep("RP-0303", "Termocupla tipo J", "Eléctrico", electrica, "E-02", 14, 5, 9800)
        r_man = rep("RP-0401", "Manguera hidráulica 3/8 in (1 m)", "Hidráulico", central, "D-02", 7, 3, 15200)
        rep("RP-0402", "Válvula direccional 4/3", "Hidráulico", central, "D-04", 1, 2, 189000)
        rep("RP-0501", "Filtro de aceite inyectora", "Filtros", central, "F-01", 10, 4, 14500)
        rep("RP-0502", "Filtro de agua caldera", "Filtros", calderas, "C-05", 4, 2, 27500)

        ex1 = Equipo.objects.create(codigo="EXT-01", nombre_habitual="La Grande", categoria="Extrusora",
                                    ubicacion="Línea 1, nave principal", marca="Davis-Standard", modelo="DS-90",
                                    criticidad="alta", estado="operativo")
        iny3 = Equipo.objects.create(codigo="INY-03", nombre_habitual="Inyectora 3 (pasillo norte)", categoria="Inyectora",
                                     ubicacion="Nave 2, pasillo norte", marca="Haitian", modelo="MA2800",
                                     criticidad="alta", estado="en_mantencion")
        iny5 = Equipo.objects.create(codigo="INY-05", nombre_habitual="La Vieja", categoria="Inyectora",
                                     ubicacion="Nave 2, fondo", marca="Engel", modelo="ES-200",
                                     criticidad="media", estado="operativo")
        cal1 = Equipo.objects.create(codigo="CAL-01", nombre_habitual="Caldera principal", categoria="Caldera",
                                     ubicacion="Sala de calderas", marca="Cleaver-Brooks", modelo="CB-200",
                                     criticidad="alta", estado="operativo")
        Equipo.objects.create(codigo="CHI-01", nombre_habitual="Chiller", categoria="Otro",
                              ubicacion="Patio técnico", marca="Carrier", modelo="30RB",
                              criticidad="media", estado="operativo")
        Equipo.objects.create(codigo="MOL-02", nombre_habitual="Molino", categoria="Otro",
                              ubicacion="Nave 1, bodega de scrap", marca="Cumberland", modelo="CU-18",
                              criticidad="baja", estado="operativo")

        ahora = timezone.now()
        rf = ReporteFalla.objects.create(equipo=iny3, operador=ope, descripcion="Hace ruido al cerrar el molde y pierde presión.",
                                         detiene_linea=True, estado="tomado", tecnico=tec)
        ot1 = OrdenTrabajo.objects.create(equipo=iny3, titulo="Pérdida de presión y ruido al cerrar molde", tipo="correctiva",
                                          prioridad="alta", estado="en_curso", asignado_a=tec, creado_por=ing, reporte=rf,
                                          descripcion="Revisar cilindro de cierre y mangueras.")
        BitacoraOT.objects.create(ot=ot1, autor=tec, texto="Se revisó nivel de aceite: normal. Se descartó la bomba.")
        BitacoraOT.objects.create(ot=ot1, autor=tec, es_traspaso=True,
                                  texto="Traspaso: manguera lateral con goteo, falta cambiar sello del cilindro. Pendiente: probar presión en vacío.")
        RepuestoOT.objects.create(ot=ot1, repuesto=r_sello, cantidad=1, estado="requerido", registrado_por=tec)
        RepuestoOT.objects.create(ot=ot1, repuesto=r_man, cantidad=1, estado="usado", registrado_por=tec)
        OrdenTrabajo.objects.filter(pk=ot1.pk).update(creada=ahora - timedelta(hours=7))
        BitacoraOT.objects.filter(ot=ot1).update(creado=ahora - timedelta(hours=6))

        ot2 = OrdenTrabajo.objects.create(equipo=ex1, titulo="Cambio de resistencias zona 3", tipo="preventiva", prioridad="media",
                                          estado="abierta", asignado_a=tec, creado_por=ing, descripcion="Cambio programado.")
        RepuestoOT.objects.create(ot=ot2, repuesto=r_res, cantidad=3, estado="requerido", registrado_por=ing)
        ot3 = OrdenTrabajo.objects.create(equipo=cal1, titulo="Limpieza de filtros de agua", tipo="preventiva", prioridad="baja",
                                          estado="cerrada", asignado_a=tec, creado_por=ing, cerrada_en=ahora - timedelta(days=3))
        RepuestoOT.objects.create(ot=ot3, repuesto=rep("RP-0503", "Filtro de agua 20 in", "Filtros", calderas, "C-06", 6, 2, 9500),
                                  cantidad=2, estado="usado", registrado_por=tec)
        BitacoraOT.objects.create(ot=ot3, autor=tec, texto="Filtros cambiados y sistema purgado.")
        RepuestoOT.objects.create(ot=ot1, repuesto=r_rod, cantidad=2, estado="usado", registrado_por=tec)

        ReporteFalla.objects.create(equipo=iny5, operador=ope, descripcion="Vibración fuerte en el husillo.", estado="enviado")

        Nota.objects.create(titulo="Revisar siempre el sello lateral", tipo="recomendacion", equipo=iny3, autor=tec,
                            texto="En esta inyectora el goteo del sello lateral se repite cada ~3 meses. Cambiar el sello completo, no solo apretar.")
        Nota.objects.create(titulo="Las resistencias de la zona 3 se agotan rápido", tipo="nota", equipo=ex1, autor=ing,
                            texto="Verificar el voltaje antes de cambiarlas. Si baja de 210 V avisar al taller eléctrico.")

        Plan.objects.create(titulo="Equipo de mantención turno A: preventivo extrusoras", tipo="equipo", equipo=ex1, responsable=tec,
                            fecha_inicio=ahora.date() + timedelta(days=2), fecha_fin=ahora.date() + timedelta(days=4),
                            descripcion="Dos técnicos, lubricación y cambio de resistencias.", creado_por=ing)
        Plan.objects.create(titulo="Optimizar ciclo de inyección INY-05", tipo="optimizacion", equipo=iny5,
                            fecha_inicio=ahora.date() + timedelta(days=7), fecha_fin=ahora.date() + timedelta(days=9),
                            descripcion="Medir tiempos de ciclo y ajustar temperaturas.", creado_por=ing)
        Informe.objects.create(titulo="Fallas de la semana en inyectoras", compartido=True, autor=ing,
                               contenido="La INY-03 concentra la mayoría de las detenciones. Causa principal: sellos del cilindro de cierre.\n"
                                         "Acción: reemplazar el kit de sellos y revisar mangueras laterales en el próximo preventivo.")
        self.stdout.write(self.style.SUCCESS("Usuarios y datos de demostración cargados."))
