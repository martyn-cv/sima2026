# Menú por rol: cada perfil ve solo su propia interfaz.
MENUS = {
    "tecnico": [
        ("Inicio", "inicio"),
        ("Avisos", "aviso_lista"),
        ("Órdenes", "ot_lista"),
        ("Equipos", "equipo_lista"),
        ("Repuestos", "repuesto_lista"),
        ("Notas", "nota_lista"),
        ("Informes", "informe_lista"),
    ],
    "ingeniero": [
        ("Inicio", "inicio"),
        ("Planificador", "plan_lista"),
        ("Órdenes", "ot_lista"),
        ("Avisos", "aviso_lista"),
        ("Equipos", "equipo_lista"),
        ("Repuestos", "repuesto_lista"),
        ("Notas", "nota_lista"),
        ("Informes", "informe_lista"),
    ],
    "operador": [
        ("Inicio", "inicio"),
        ("Equipos", "equipo_lista"),
        ("Avisar falla", "aviso_nuevo"),
        ("Mis reportes", "mis_reportes"),
    ],
}


def navegacion(request):
    perfil = getattr(request.user, "perfil", None) if request.user.is_authenticated else None
    if perfil is None:
        return {}
    return {"rol": perfil.rol, "rol_nombre": perfil.get_rol_display(), "menu": MENUS.get(perfil.rol, [])}
