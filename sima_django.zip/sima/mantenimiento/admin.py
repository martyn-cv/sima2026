from django.contrib import admin

from . import models


class SoloLectura(admin.ModelAdmin):
    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(models.BitacoraOT)
class BitacoraAdmin(SoloLectura):
    list_display = ("ot", "autor", "es_traspaso", "creado")


@admin.register(models.Repuesto)
class RepuestoAdmin(admin.ModelAdmin):
    list_display = ("codigo", "nombre", "tipo", "bodega", "stock", "stock_minimo")
    list_filter = ("bodega", "tipo")
    search_fields = ("codigo", "nombre")


@admin.register(models.Equipo)
class EquipoAdmin(admin.ModelAdmin):
    list_display = ("codigo", "nombre_habitual", "categoria", "ubicacion", "criticidad", "estado")
    list_filter = ("categoria", "criticidad", "estado")
    search_fields = ("codigo", "nombre_habitual")


for modelo in (models.Bodega, models.TipoRepuesto, models.ReporteFalla, models.OrdenTrabajo,
               models.RepuestoOT, models.Nota, models.Plan, models.Informe):
    admin.site.register(modelo)
