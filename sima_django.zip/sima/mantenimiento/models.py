from datetime import timedelta

from django.conf import settings
from django.db import models
from django.utils import timezone

Usuario = settings.AUTH_USER_MODEL
HORAS_SIN_AVANCE = 4  # umbral de la historia "Continuidad entre turnos"


class Bodega(models.Model):
    nombre = models.CharField(max_length=80, unique=True)
    ubicacion = models.CharField("Ubicación", max_length=120, blank=True)

    class Meta:
        ordering = ["nombre"]

    def __str__(self):
        return self.nombre


class TipoRepuesto(models.Model):
    nombre = models.CharField(max_length=80, unique=True)

    class Meta:
        ordering = ["nombre"]
        verbose_name = "tipo de repuesto"
        verbose_name_plural = "tipos de repuesto"

    def __str__(self):
        return self.nombre


class Repuesto(models.Model):
    codigo = models.CharField("Código", max_length=20, unique=True)
    nombre = models.CharField(max_length=120)
    tipo = models.ForeignKey(TipoRepuesto, on_delete=models.PROTECT, related_name="repuestos")
    bodega = models.ForeignKey(Bodega, on_delete=models.PROTECT, related_name="repuestos")
    estante = models.CharField(max_length=20, blank=True)
    stock = models.PositiveIntegerField(default=0)
    stock_minimo = models.PositiveIntegerField("Stock mínimo", default=0)
    costo_unitario = models.PositiveIntegerField("Costo unitario (CLP)", default=0)

    class Meta:
        ordering = ["nombre"]

    def __str__(self):
        return f"{self.codigo} {self.nombre}"

    @property
    def bajo_minimo(self):
        return self.stock <= self.stock_minimo


class Equipo(models.Model):
    CATEGORIAS = [("Extrusora", "Extrusora"), ("Inyectora", "Inyectora"), ("Caldera", "Caldera"), ("Otro", "Otro")]
    CRITICIDAD = [("alta", "Alta"), ("media", "Media"), ("baja", "Baja")]
    ESTADOS = [("operativo", "Operativo"), ("en_mantencion", "En mantención"), ("detenido", "Detenido")]

    codigo = models.CharField("Código interno", max_length=20, unique=True)
    nombre_habitual = models.CharField("Nombre habitual", max_length=80)
    categoria = models.CharField(max_length=20, choices=CATEGORIAS, default="Otro")
    ubicacion = models.CharField("Ubicación", max_length=120)
    marca = models.CharField(max_length=60, blank=True)
    modelo = models.CharField(max_length=60, blank=True)
    criticidad = models.CharField(max_length=10, choices=CRITICIDAD, default="media")
    estado = models.CharField(max_length=20, choices=ESTADOS, default="operativo")
    manual = models.FileField(upload_to="manuales/", blank=True)
    foto_placa = models.FileField("Foto de la placa", upload_to="placas/", blank=True)

    class Meta:
        ordering = ["nombre_habitual"]

    def __str__(self):
        return f"{self.nombre_habitual} ({self.codigo})"


class ReporteFalla(models.Model):
    ESTADOS = [("enviado", "Enviado"), ("tomado", "Tomado por un técnico"), ("resuelto", "Resuelto")]

    equipo = models.ForeignKey(Equipo, on_delete=models.PROTECT, related_name="reportes")
    operador = models.ForeignKey(Usuario, on_delete=models.PROTECT, related_name="reportes_enviados")
    descripcion = models.TextField("¿Qué le pasa a la máquina?")
    foto = models.FileField("Foto (placa o falla)", upload_to="reportes/", blank=True)
    detiene_linea = models.BooleanField("Detiene la línea", default=False)
    estado = models.CharField(max_length=10, choices=ESTADOS, default="enviado")
    tecnico = models.ForeignKey(Usuario, on_delete=models.SET_NULL, null=True, blank=True, related_name="reportes_tomados")
    creado = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-creado"]
        verbose_name_plural = "reportes de falla"

    def __str__(self):
        return f"Reporte #{self.pk} · {self.equipo.nombre_habitual}"


class OrdenTrabajo(models.Model):
    TIPOS = [("correctiva", "Correctiva"), ("preventiva", "Preventiva")]
    PRIORIDADES = [("alta", "Alta"), ("media", "Media"), ("baja", "Baja")]
    ESTADOS = [("abierta", "Abierta"), ("en_curso", "En curso"), ("cerrada", "Cerrada")]

    equipo = models.ForeignKey(Equipo, on_delete=models.PROTECT, related_name="ordenes")
    titulo = models.CharField("Título", max_length=140)
    descripcion = models.TextField("Descripción", blank=True)
    tipo = models.CharField(max_length=12, choices=TIPOS, default="correctiva")
    prioridad = models.CharField(max_length=10, choices=PRIORIDADES, default="media")
    estado = models.CharField(max_length=10, choices=ESTADOS, default="abierta")
    asignado_a = models.ForeignKey(Usuario, on_delete=models.SET_NULL, null=True, blank=True, related_name="ordenes_asignadas")
    creado_por = models.ForeignKey(Usuario, on_delete=models.PROTECT, related_name="ordenes_creadas")
    reporte = models.OneToOneField(ReporteFalla, on_delete=models.SET_NULL, null=True, blank=True, related_name="orden")
    creada = models.DateTimeField(auto_now_add=True)
    cerrada_en = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-creada"]
        verbose_name = "orden de trabajo"
        verbose_name_plural = "órdenes de trabajo"

    def __str__(self):
        return f"OT-{self.pk:04d} {self.titulo}"

    @property
    def numero(self):
        return f"OT-{self.pk:04d}"

    @property
    def abierta(self):
        return self.estado != "cerrada"

    @property
    def ultimo_avance(self):
        ultima = self.bitacora.order_by("-creado").first()
        return ultima.creado if ultima else self.creada

    @property
    def sin_avance(self):
        """Equipo crítico con la OT abierta y sin registros en la bitácora por 4 horas."""
        return (self.abierta and self.equipo.criticidad == "alta"
                and timezone.now() - self.ultimo_avance > timedelta(hours=HORAS_SIN_AVANCE))

    @property
    def horas_sin_avance(self):
        return int((timezone.now() - self.ultimo_avance).total_seconds() // 3600)


class BitacoraOT(models.Model):
    """Registro cronológico: no se puede editar ni borrar."""
    ot = models.ForeignKey(OrdenTrabajo, on_delete=models.CASCADE, related_name="bitacora")
    autor = models.ForeignKey(Usuario, on_delete=models.PROTECT)
    texto = models.TextField()
    es_traspaso = models.BooleanField("Nota de traspaso", default=False)
    creado = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["creado"]
        verbose_name = "registro de bitácora"
        verbose_name_plural = "bitácora"

    def save(self, *args, **kwargs):
        if self.pk:
            raise PermissionError("La bitácora no se puede editar.")
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        raise PermissionError("La bitácora no se puede borrar.")


class RepuestoOT(models.Model):
    ESTADOS = [("requerido", "Requerido"), ("usado", "Usado")]

    ot = models.ForeignKey(OrdenTrabajo, on_delete=models.CASCADE, related_name="repuestos")
    repuesto = models.ForeignKey(Repuesto, on_delete=models.PROTECT, related_name="usos")
    cantidad = models.PositiveIntegerField()
    estado = models.CharField(max_length=10, choices=ESTADOS, default="requerido")
    registrado_por = models.ForeignKey(Usuario, on_delete=models.PROTECT)
    creado = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["creado"]

    @property
    def suficiente(self):
        return self.repuesto.stock >= self.cantidad

    @property
    def costo_total(self):
        return self.cantidad * self.repuesto.costo_unitario


class Nota(models.Model):
    TIPOS = [("recomendacion", "Recomendación"), ("nota", "Nota")]

    titulo = models.CharField(max_length=140)
    texto = models.TextField()
    tipo = models.CharField(max_length=15, choices=TIPOS, default="recomendacion")
    equipo = models.ForeignKey(Equipo, on_delete=models.SET_NULL, null=True, blank=True, related_name="notas")
    autor = models.ForeignKey(Usuario, on_delete=models.PROTECT)
    creada = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-creada"]

    def __str__(self):
        return self.titulo


class Plan(models.Model):
    TIPOS = [("equipo", "Equipo de mantenimiento"), ("optimizacion", "Optimización de máquinas"), ("preventivo", "Mantención preventiva")]
    ESTADOS = [("planificado", "Planificado"), ("en_curso", "En curso"), ("completado", "Completado")]

    titulo = models.CharField(max_length=140)
    tipo = models.CharField(max_length=15, choices=TIPOS, default="preventivo")
    equipo = models.ForeignKey(Equipo, on_delete=models.SET_NULL, null=True, blank=True)
    responsable = models.ForeignKey(Usuario, on_delete=models.SET_NULL, null=True, blank=True, related_name="planes")
    fecha_inicio = models.DateField("Desde")
    fecha_fin = models.DateField("Hasta")
    descripcion = models.TextField("Detalle", blank=True)
    estado = models.CharField(max_length=12, choices=ESTADOS, default="planificado")
    creado_por = models.ForeignKey(Usuario, on_delete=models.PROTECT, related_name="planes_creados")

    class Meta:
        ordering = ["fecha_inicio"]

    def __str__(self):
        return self.titulo


class Informe(models.Model):
    titulo = models.CharField(max_length=140)
    contenido = models.TextField()
    compartido = models.BooleanField("Compartir con los técnicos", default=False)
    autor = models.ForeignKey(Usuario, on_delete=models.PROTECT)
    creado = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-creado"]

    def __str__(self):
        return self.titulo
