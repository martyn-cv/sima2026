from django.urls import path, re_path

from . import views

urlpatterns = [
    path("", views.inicio, name="inicio"),
    path("equipos/", views.equipo_lista, name="equipo_lista"),
    path("equipos/<int:pk>/", views.equipo_detalle, name="equipo_detalle"),
    path("equipos/<int:pk>/manual/", views.equipo_manual, name="equipo_manual"),
    path("repuestos/", views.repuesto_lista, name="repuesto_lista"),
    path("avisos/", views.aviso_lista, name="aviso_lista"),
    path("avisos/nuevo/", views.aviso_nuevo, name="aviso_nuevo"),
    path("avisos/<int:pk>/tomar/", views.aviso_tomar, name="aviso_tomar"),
    path("mis-reportes/", views.mis_reportes, name="mis_reportes"),
    path("ordenes/", views.ot_lista, name="ot_lista"),
    path("ordenes/nueva/", views.ot_nueva, name="ot_nueva"),
    path("ordenes/<int:pk>/", views.ot_detalle, name="ot_detalle"),
    path("ordenes/<int:pk>/bitacora/", views.ot_bitacora, name="ot_bitacora"),
    path("ordenes/<int:pk>/repuesto/", views.ot_repuesto, name="ot_repuesto"),
    path("ordenes/<int:pk>/estado/", views.ot_estado, name="ot_estado"),
    path("notas/", views.nota_lista, name="nota_lista"),
    path("notas/nueva/", views.nota_nueva, name="nota_nueva"),
    path("planificador/", views.plan_lista, name="plan_lista"),
    path("planificador/nuevo/", views.plan_nuevo, name="plan_nuevo"),
    path("planificador/<int:pk>/estado/", views.plan_estado, name="plan_estado"),
    path("informes/", views.informe_lista, name="informe_lista"),
    path("informes/nuevo/", views.informe_nuevo, name="informe_nuevo"),
    path("informes/<int:pk>/", views.informe_detalle, name="informe_detalle"),
    path("informes/<int:pk>/compartir/", views.informe_compartir, name="informe_compartir"),
    re_path(r"^media/(?P<path>.*)$", views.media, name="media"),
]
