from django.contrib.auth import get_user_model
from django.core.management import call_command
from django.test import TestCase
from django.urls import reverse

from .models import BitacoraOT, OrdenTrabajo, Repuesto, ReporteFalla

User = get_user_model()
CLAVES = {"tecnico@manuandina.cl": "Tecnico2026", "ingeniero@manuandina.cl": "Ingeniero2026", "operador@manuandina.cl": "Operador2026"}


class BaseSima(TestCase):
    @classmethod
    def setUpTestData(cls):
        call_command("seed_demo", verbosity=0)

    def entrar(self, email):
        self.client.post(reverse("login"), {"email": email, "password": CLAVES[email]})


class LoginTests(BaseSima):
    def test_dominio_distinto_es_rechazado(self):
        r = self.client.post(reverse("login"), {"email": "alguien@gmail.com", "password": "Tecnico2026"})
        self.assertContains(r, "@manuandina.cl")
        self.assertNotIn("_auth_user_id", self.client.session)

    def test_usuario_del_dominio_no_autorizado_es_rechazado(self):
        r = self.client.post(reverse("login"), {"email": "otro@manuandina.cl", "password": "Cualquiera123"})
        self.assertContains(r, "incorrectos")

    def test_clave_incorrecta(self):
        r = self.client.post(reverse("login"), {"email": "tecnico@manuandina.cl", "password": "mala"})
        self.assertNotIn("_auth_user_id", self.client.session)
        self.assertContains(r, "incorrectos")

    def test_sin_sesion_redirige_al_login(self):
        self.assertEqual(self.client.get(reverse("inicio")).status_code, 302)

    def test_cada_rol_ve_su_inicio(self):
        esperado = {"tecnico@manuandina.cl": "Mis órdenes", "ingeniero@manuandina.cl": "Planificador", "operador@manuandina.cl": "Avisar una falla"}
        for email, texto in esperado.items():
            self.client.logout()
            self.entrar(email)
            self.assertContains(self.client.get(reverse("inicio")), texto)


class PermisosTests(BaseSima):
    def test_tecnico_no_entra_al_planificador(self):
        self.entrar("tecnico@manuandina.cl")
        self.assertEqual(self.client.get(reverse("plan_lista")).status_code, 403)

    def test_operador_no_ve_repuestos_ni_ordenes(self):
        self.entrar("operador@manuandina.cl")
        for nombre in ("repuesto_lista", "ot_lista", "nota_lista", "plan_lista"):
            self.assertEqual(self.client.get(reverse(nombre)).status_code, 403, nombre)

    def test_ingeniero_accede_al_planificador_y_tecnico_a_repuestos(self):
        self.entrar("ingeniero@manuandina.cl")
        self.assertEqual(self.client.get(reverse("plan_lista")).status_code, 200)
        self.client.logout()
        self.entrar("tecnico@manuandina.cl")
        r = self.client.get(reverse("repuesto_lista"))
        self.assertContains(r, "Bodega Central")

    def test_tecnico_solo_ve_informes_compartidos(self):
        from .models import Informe
        privado = Informe.objects.create(titulo="Borrador privado", contenido="x", autor=User.objects.get(username="ingeniero@manuandina.cl"))
        self.entrar("tecnico@manuandina.cl")
        self.assertNotContains(self.client.get(reverse("informe_lista")), "Borrador privado")
        self.assertEqual(self.client.get(reverse("informe_detalle", args=[privado.pk])).status_code, 404)


class FlujoTests(BaseSima):
    def test_filtro_repuestos_por_bodega(self):
        self.entrar("tecnico@manuandina.cl")
        r = self.client.get(reverse("repuesto_lista"), {"bodega": 3})
        self.assertContains(r, "Contactor 3P 25A")
        self.assertNotContains(r, "Rodamiento 6208")

    def test_usar_repuesto_descuenta_stock_y_registra_bitacora(self):
        self.entrar("tecnico@manuandina.cl")
        ot = OrdenTrabajo.objects.get(titulo__startswith="Pérdida")
        rep = Repuesto.objects.get(codigo="RP-0101")
        antes = rep.stock
        self.client.post(reverse("ot_repuesto", args=[ot.pk]), {"repuesto": rep.pk, "cantidad": 2, "accion": "usar"})
        rep.refresh_from_db()
        self.assertEqual(rep.stock, antes - 2)
        self.assertTrue(ot.bitacora.filter(texto__contains="Repuesto usado").exists())

    def test_no_se_puede_usar_mas_que_el_stock(self):
        self.entrar("tecnico@manuandina.cl")
        ot = OrdenTrabajo.objects.get(titulo__startswith="Pérdida")
        rep = Repuesto.objects.get(codigo="RP-0402")
        self.client.post(reverse("ot_repuesto", args=[ot.pk]), {"repuesto": rep.pk, "cantidad": 5, "accion": "usar"})
        rep.refresh_from_db()
        self.assertEqual(rep.stock, 1)

    def test_bitacora_no_se_edita_ni_borra(self):
        registro = BitacoraOT.objects.first()
        registro.texto = "cambiado"
        with self.assertRaises(PermissionError):
            registro.save()
        with self.assertRaises(PermissionError):
            registro.delete()

    def test_operador_reporta_tecnico_toma_y_operador_ve_el_estado(self):
        self.entrar("operador@manuandina.cl")
        equipo_id = ReporteFalla.objects.first().equipo_id
        self.client.post(reverse("aviso_nuevo"), {"equipo": equipo_id, "descripcion": "Se calienta mucho"})
        aviso = ReporteFalla.objects.get(descripcion="Se calienta mucho")
        self.client.logout()
        self.entrar("tecnico@manuandina.cl")
        self.client.post(reverse("aviso_tomar", args=[aviso.pk]))
        aviso.refresh_from_db()
        self.assertEqual(aviso.estado, "tomado")
        self.client.logout()
        self.entrar("operador@manuandina.cl")
        self.assertContains(self.client.get(reverse("mis_reportes")), "Tomado por un técnico")

    def test_aviso_sin_descripcion_se_rechaza(self):
        self.entrar("operador@manuandina.cl")
        n = ReporteFalla.objects.count()
        r = self.client.post(reverse("aviso_nuevo"), {"equipo": "", "descripcion": ""})
        self.assertEqual(ReporteFalla.objects.count(), n)
        self.assertContains(r, "obligatorio")

    def test_ot_critica_sin_avance_genera_alerta_al_ingeniero(self):
        self.entrar("ingeniero@manuandina.cl")
        self.assertContains(self.client.get(reverse("inicio")), "horas sin avance")

    def test_ingeniero_comparte_informe_y_tecnico_lo_lee(self):
        self.entrar("ingeniero@manuandina.cl")
        self.client.post(reverse("informe_nuevo"), {"titulo": "Plan de lubricación", "contenido": "Detalle", "compartido": "on"})
        self.client.logout()
        self.entrar("tecnico@manuandina.cl")
        self.assertContains(self.client.get(reverse("informe_lista")), "Plan de lubricación")
