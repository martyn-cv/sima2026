from django import forms
from django.contrib.auth import get_user_model

from .models import Equipo, Informe, Nota, OrdenTrabajo, Plan, Repuesto, ReporteFalla


class EquipoSelect(forms.ModelChoiceField):
    def label_from_instance(self, obj):
        return f"{obj.nombre_habitual} · {obj.ubicacion}"


class ReporteFallaForm(forms.ModelForm):
    equipo = EquipoSelect(queryset=Equipo.objects.all(), empty_label="Elija la máquina", label="Máquina")

    class Meta:
        model = ReporteFalla
        fields = ["equipo", "descripcion", "foto", "detiene_linea"]
        widgets = {"descripcion": forms.Textarea(attrs={"rows": 4, "placeholder": "Cuente brevemente qué está pasando"}),
                   "foto": forms.ClearableFileInput(attrs={"accept": "image/*", "capture": "environment"})}


class OrdenTrabajoForm(forms.ModelForm):
    equipo = EquipoSelect(queryset=Equipo.objects.all(), empty_label="Elija el equipo")

    class Meta:
        model = OrdenTrabajo
        fields = ["equipo", "titulo", "descripcion", "tipo", "prioridad", "asignado_a"]
        widgets = {"descripcion": forms.Textarea(attrs={"rows": 3})}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["asignado_a"].queryset = get_user_model().objects.filter(perfil__rol="tecnico")
        self.fields["asignado_a"].label = "Asignar a"
        self.fields["asignado_a"].empty_label = "Sin asignar"


class BitacoraForm(forms.Form):
    texto = forms.CharField(label="Acción realizada", widget=forms.Textarea(attrs={"rows": 3}))
    es_traspaso = forms.BooleanField(label="Es nota de traspaso (para el siguiente turno)", required=False)


class RepuestoOTForm(forms.Form):
    ACCIONES = [("requerir", "Requerir (aún no lo uso)"), ("usar", "Usar ahora (descuenta stock)")]
    repuesto = forms.ModelChoiceField(queryset=Repuesto.objects.select_related("bodega"), label="Repuesto")
    cantidad = forms.IntegerField(min_value=1, initial=1)
    accion = forms.ChoiceField(choices=ACCIONES, initial="requerir", label="¿Qué quiere hacer?")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["repuesto"].label_from_instance = lambda r: f"{r.nombre} · {r.bodega.nombre} · stock {r.stock}"


class ManualForm(forms.ModelForm):
    class Meta:
        model = Equipo
        fields = ["manual"]
        widgets = {"manual": forms.ClearableFileInput(attrs={"accept": ".pdf,.doc,.docx"})}


class NotaForm(forms.ModelForm):
    class Meta:
        model = Nota
        fields = ["tipo", "titulo", "equipo", "texto"]
        widgets = {"texto": forms.Textarea(attrs={"rows": 5, "placeholder": "Escriba la recomendación o la nota para otros técnicos"})}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["equipo"].required = False
        self.fields["equipo"].empty_label = "General (sin equipo)"
        self.fields["texto"].label = "Detalle"


class PlanForm(forms.ModelForm):
    class Meta:
        model = Plan
        fields = ["titulo", "tipo", "equipo", "responsable", "fecha_inicio", "fecha_fin", "descripcion"]
        widgets = {"fecha_inicio": forms.DateInput(attrs={"type": "date"}, format="%Y-%m-%d"),
                   "fecha_fin": forms.DateInput(attrs={"type": "date"}, format="%Y-%m-%d"),
                   "descripcion": forms.Textarea(attrs={"rows": 3})}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["equipo"].required = False
        self.fields["equipo"].empty_label = "Sin equipo específico"
        self.fields["responsable"].queryset = get_user_model().objects.filter(perfil__rol="tecnico")
        self.fields["responsable"].empty_label = "Sin responsable"

    def clean(self):
        data = super().clean()
        if data.get("fecha_inicio") and data.get("fecha_fin") and data["fecha_fin"] < data["fecha_inicio"]:
            self.add_error("fecha_fin", "La fecha final no puede ser anterior a la inicial.")
        return data


class InformeForm(forms.ModelForm):
    class Meta:
        model = Informe
        fields = ["titulo", "contenido", "compartido"]
        widgets = {"contenido": forms.Textarea(attrs={"rows": 10})}
