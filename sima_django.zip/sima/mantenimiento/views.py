from collections import defaultdict

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.db.models import Count, F, Prefetch, Q
from django.http import Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST
from django.views.static import serve as servir_archivo
from django.conf import settings

from accounts.decorators import rol_requerido

from .forms import (BitacoraForm, InformeForm, ManualForm, NotaForm, OrdenTrabajoForm, PlanForm,
                    ReporteFallaForm, RepuestoOTForm)
from .models import (BitacoraOT, Equipo, Informe, Nota, OrdenTrabajo, Plan, Repuesto, RepuestoOT,
                     ReporteFalla, Bodega, TipoRepuesto)

TECNICO, INGENIERO, OPERADOR = "tecnico", "ingeniero", "operador"
PLANTA = (TECNICO, INGENIERO)  # roles de mantenimiento


# ---------- Inicio (cada rol ve su propia pantalla) ----------
@login_required
def inicio(request):
    rol = request.user.perfil.rol
    if rol == OPERADOR:
        return render(request, "mantenimiento/inicio_operador.html", {
            "pendientes": ReporteFalla.objects.filter(operador=request.user).exclude(estado="resuelto").count()})
    ctx = {
        "stock_bajo": [r for r in Repuesto.objects.select_related("bodega", "tipo") if r.bajo_minimo][:5],
        "avisos_sin_tomar": ReporteFalla.objects.filter(estado="enviado").select_related("equipo"),
        "notas": Nota.objects.select_related("autor", "equipo")[:3],
    }
    if rol == TECNICO:
        ctx["mis_ot"] = (OrdenTrabajo.objects.filter(asignado_a=request.user).exclude(estado="cerrada")
                         .select_related("equipo"))
        ctx["informes"] = Informe.objects.filter(compartido=True)[:3]
        return render(request, "mantenimiento/inicio_tecnico.html", ctx)
    abiertas = OrdenTrabajo.objects.exclude(estado="cerrada").select_related("equipo", "asignado_a")
    ctx["abiertas"] = abiertas.count()
    ctx["alertas"] = [ot for ot in abiertas if ot.sin_avance]
    ctx["proximos"] = Plan.objects.exclude(estado="completado").select_related("equipo")[:4]
    return render(request, "mantenimiento/inicio_ingeniero.html", ctx)


# ---------- Equipos ----------
@login_required
def equipo_lista(request):
    q = request.GET.get("q", "").strip()
    categoria = request.GET.get("categoria", "")
    equipos = Equipo.objects.all()
    if q:
        equipos = equipos.filter(Q(nombre_habitual__icontains=q) | Q(codigo__icontains=q) | Q(ubicacion__icontains=q))
    if categoria:
        equipos = equipos.filter(categoria=categoria)
    return render(request, "mantenimiento/equipo_lista.html", {
        "equipos": equipos, "q": q, "categoria": categoria, "categorias": [c[0] for c in Equipo.CATEGORIAS]})


@login_required
def equipo_detalle(request, pk):
    equipo = get_object_or_404(Equipo, pk=pk)
    ctx = {"equipo": equipo}
    if request.user.perfil.rol in PLANTA:
        usados = Prefetch("repuestos", queryset=RepuestoOT.objects.filter(estado="usado").select_related("repuesto"), to_attr="usados")
        ctx["historial"] = equipo.ordenes.prefetch_related(usados)[:5]
        ctx["notas"] = equipo.notas.select_related("autor")[:3]
        ctx["manual_form"] = ManualForm()
    return render(request, "mantenimiento/equipo_detalle.html", ctx)


@require_POST
@rol_requerido(*PLANTA)
def equipo_manual(request, pk):
    equipo = get_object_or_404(Equipo, pk=pk)
    form = ManualForm(request.POST, request.FILES, instance=equipo)
    if form.is_valid() and request.FILES.get("manual"):
        form.save()
        messages.success(request, "Manual cargado.")
    else:
        messages.error(request, "Elija un archivo para cargar el manual.")
    return redirect("equipo_detalle", pk=pk)


# ---------- Repuestos y bodegas ----------
@rol_requerido(*PLANTA)
def repuesto_lista(request):
    q = request.GET.get("q", "").strip()
    bodega = request.GET.get("bodega", "")
    tipo = request.GET.get("tipo", "")
    solo_bajo = request.GET.get("bajo") == "1"
    repuestos = Repuesto.objects.select_related("bodega", "tipo")
    if q:
        repuestos = repuestos.filter(Q(nombre__icontains=q) | Q(codigo__icontains=q))
    if bodega:
        repuestos = repuestos.filter(bodega_id=bodega)
    if tipo:
        repuestos = repuestos.filter(tipo_id=tipo)
    repuestos = list(repuestos)
    if solo_bajo:
        repuestos = [r for r in repuestos if r.bajo_minimo]
    return render(request, "mantenimiento/repuesto_lista.html", {
        "repuestos": repuestos, "q": q, "bodega": bodega, "tipo": tipo, "solo_bajo": solo_bajo,
        "bodegas": Bodega.objects.annotate(n=Count("repuestos")), "tipos": TipoRepuesto.objects.all()})


# ---------- Avisos de falla (operadores) ----------
@rol_requerido(OPERADOR, TECNICO, INGENIERO)
def aviso_nuevo(request):
    form = ReporteFallaForm(request.POST or None, request.FILES or None)
    if request.method == "POST" and form.is_valid():
        reporte = form.save(commit=False)
        reporte.operador = request.user
        reporte.save()
        messages.success(request, "Aviso enviado. Mantención ya puede verlo.")
        return redirect("mis_reportes" if request.user.perfil.rol == OPERADOR else "aviso_lista")
    return render(request, "mantenimiento/aviso_nuevo.html", {"form": form})


@rol_requerido(OPERADOR)
def mis_reportes(request):
    reportes = ReporteFalla.objects.filter(operador=request.user).select_related("equipo", "tecnico")
    return render(request, "mantenimiento/mis_reportes.html", {"reportes": reportes})


@rol_requerido(*PLANTA)
def aviso_lista(request):
    avisos = ReporteFalla.objects.select_related("equipo", "operador", "tecnico").order_by("estado", "-creado")
    return render(request, "mantenimiento/aviso_lista.html", {"avisos": avisos})


@require_POST
@rol_requerido(TECNICO)
def aviso_tomar(request, pk):
    with transaction.atomic():
        aviso = get_object_or_404(ReporteFalla.objects.select_for_update(), pk=pk)
        if aviso.estado != "enviado":
            messages.error(request, "Este aviso ya fue tomado por otro técnico.")
            return redirect("aviso_lista")
        ot = OrdenTrabajo.objects.create(
            equipo=aviso.equipo, titulo=aviso.descripcion[:120], descripcion=aviso.descripcion, tipo="correctiva",
            prioridad="alta" if aviso.detiene_linea else "media", estado="en_curso",
            asignado_a=request.user, creado_por=request.user, reporte=aviso)
        aviso.estado, aviso.tecnico = "tomado", request.user
        aviso.save(update_fields=["estado", "tecnico"])
        BitacoraOT.objects.create(ot=ot, autor=request.user, texto="Aviso tomado. Se inicia la intervención.")
    messages.success(request, f"Tomó el aviso. Se creó la {ot.numero}.")
    return redirect("ot_detalle", pk=ot.pk)


# ---------- Órdenes de trabajo ----------
@rol_requerido(*PLANTA)
def ot_lista(request):
    filtro = request.GET.get("f", "abiertas")
    ordenes = OrdenTrabajo.objects.select_related("equipo", "asignado_a")
    if filtro == "mias":
        ordenes = ordenes.filter(asignado_a=request.user).exclude(estado="cerrada")
    elif filtro == "cerradas":
        ordenes = ordenes.filter(estado="cerrada")
    else:
        filtro = "abiertas"
        ordenes = ordenes.exclude(estado="cerrada")
    return render(request, "mantenimiento/ot_lista.html", {"ordenes": ordenes, "filtro": filtro})


@rol_requerido(*PLANTA)
def ot_nueva(request):
    form = OrdenTrabajoForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        ot = form.save(commit=False)
        ot.creado_por = request.user
        ot.save()
        messages.success(request, f"Se creó la {ot.numero}.")
        return redirect("ot_detalle", pk=ot.pk)
    return render(request, "mantenimiento/formulario.html", {"form": form, "titulo": "Nueva orden de trabajo", "boton": "Crear orden"})


@rol_requerido(*PLANTA)
def ot_detalle(request, pk):
    ot = get_object_or_404(OrdenTrabajo.objects.select_related("equipo", "asignado_a"), pk=pk)
    return render(request, "mantenimiento/ot_detalle.html", {
        "ot": ot,
        "bitacora": ot.bitacora.select_related("autor"),
        "traspaso": ot.bitacora.filter(es_traspaso=True).select_related("autor").last(),
        "repuestos": ot.repuestos.select_related("repuesto", "repuesto__bodega"),
        "bitacora_form": BitacoraForm(),
        "repuesto_form": RepuestoOTForm(),
    })


def _ot_abierta_o_error(request, pk):
    ot = get_object_or_404(OrdenTrabajo, pk=pk)
    if not ot.abierta:
        messages.error(request, "La orden está cerrada; ya no admite cambios.")
        return None
    return ot


@require_POST
@rol_requerido(*PLANTA)
def ot_bitacora(request, pk):
    ot = _ot_abierta_o_error(request, pk)
    if ot is None:
        return redirect("ot_detalle", pk=pk)
    form = BitacoraForm(request.POST)
    if form.is_valid():
        BitacoraOT.objects.create(ot=ot, autor=request.user, texto=form.cleaned_data["texto"],
                                  es_traspaso=form.cleaned_data["es_traspaso"])
        if ot.estado == "abierta":
            ot.estado = "en_curso"
            ot.save(update_fields=["estado"])
        messages.success(request, "Registro guardado en la bitácora.")
    else:
        messages.error(request, "Escriba la acción realizada antes de guardar.")
    return redirect("ot_detalle", pk=pk)


@require_POST
@rol_requerido(*PLANTA)
def ot_repuesto(request, pk):
    ot = _ot_abierta_o_error(request, pk)
    if ot is None:
        return redirect("ot_detalle", pk=pk)
    form = RepuestoOTForm(request.POST)
    if not form.is_valid():
        messages.error(request, "Revise el repuesto y la cantidad.")
        return redirect("ot_detalle", pk=pk)
    cantidad, accion = form.cleaned_data["cantidad"], form.cleaned_data["accion"]
    with transaction.atomic():
        repuesto = Repuesto.objects.select_for_update().get(pk=form.cleaned_data["repuesto"].pk)
        if accion == "usar":
            if repuesto.stock < cantidad:
                messages.error(request, f"No hay stock suficiente de {repuesto.nombre} (disponible: {repuesto.stock}).")
                return redirect("ot_detalle", pk=pk)
            Repuesto.objects.filter(pk=repuesto.pk).update(stock=F("stock") - cantidad)
            RepuestoOT.objects.create(ot=ot, repuesto=repuesto, cantidad=cantidad, estado="usado", registrado_por=request.user)
            BitacoraOT.objects.create(ot=ot, autor=request.user, texto=f"Repuesto usado: {repuesto.nombre} × {cantidad}.")
            messages.success(request, "Repuesto descontado del stock y ligado a la orden.")
        else:
            RepuestoOT.objects.create(ot=ot, repuesto=repuesto, cantidad=cantidad, estado="requerido", registrado_por=request.user)
            messages.success(request, "Repuesto agregado como requerido.")
    return redirect("ot_detalle", pk=pk)


@require_POST
@rol_requerido(*PLANTA)
def ot_estado(request, pk):
    ot = get_object_or_404(OrdenTrabajo, pk=pk)
    nuevo = request.POST.get("estado")
    if nuevo == "en_curso" and ot.estado == "abierta":
        ot.estado = "en_curso"
        BitacoraOT.objects.create(ot=ot, autor=request.user, texto="Se inicia la intervención.")
    elif nuevo == "cerrada" and ot.abierta:
        ot.estado, ot.cerrada_en = "cerrada", timezone.now()
        BitacoraOT.objects.create(ot=ot, autor=request.user, texto="Orden cerrada.")
        if ot.reporte_id:
            ReporteFalla.objects.filter(pk=ot.reporte_id).update(estado="resuelto")
    else:
        messages.error(request, "Ese cambio de estado no es válido.")
        return redirect("ot_detalle", pk=pk)
    ot.save()
    messages.success(request, "Estado actualizado.")
    return redirect("ot_detalle", pk=pk)


# ---------- Notas y recomendaciones ----------
@rol_requerido(*PLANTA)
def nota_lista(request):
    tipo = request.GET.get("tipo", "")
    notas = Nota.objects.select_related("autor", "equipo")
    if tipo in ("recomendacion", "nota"):
        notas = notas.filter(tipo=tipo)
    return render(request, "mantenimiento/nota_lista.html", {"notas": notas, "tipo": tipo})


@rol_requerido(*PLANTA)
def nota_nueva(request):
    form = NotaForm(request.POST or None, initial={"equipo": request.GET.get("equipo")})
    if request.method == "POST" and form.is_valid():
        nota = form.save(commit=False)
        nota.autor = request.user
        nota.save()
        messages.success(request, "Nota publicada. Los demás técnicos ya pueden leerla.")
        return redirect("nota_lista")
    return render(request, "mantenimiento/formulario.html", {"form": form, "titulo": "Nueva nota o recomendación", "boton": "Publicar nota"})


# ---------- Planificador (ingeniero) ----------
@rol_requerido(INGENIERO)
def plan_lista(request):
    planes = Plan.objects.select_related("equipo", "responsable")
    grupos = defaultdict(list)
    for p in planes:
        grupos[p.estado].append(p)
    orden = [("en_curso", "En curso"), ("planificado", "Planificado"), ("completado", "Completado")]
    return render(request, "mantenimiento/plan_lista.html", {"grupos": [(t, grupos[k]) for k, t in orden]})


@rol_requerido(INGENIERO)
def plan_nuevo(request):
    form = PlanForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        plan = form.save(commit=False)
        plan.creado_por = request.user
        plan.save()
        messages.success(request, "Plan guardado en el planificador.")
        return redirect("plan_lista")
    return render(request, "mantenimiento/formulario.html", {"form": form, "titulo": "Nuevo plan", "boton": "Guardar plan"})


@require_POST
@rol_requerido(INGENIERO)
def plan_estado(request, pk):
    plan = get_object_or_404(Plan, pk=pk)
    nuevo = request.POST.get("estado")
    if nuevo in dict(Plan.ESTADOS):
        plan.estado = nuevo
        plan.save(update_fields=["estado"])
    return redirect("plan_lista")


# ---------- Informes ----------
def _indicadores():
    fallas = (ReporteFalla.objects.values("equipo__nombre_habitual").annotate(n=Count("id")).order_by("-n")[:5])
    consumo = defaultdict(int)
    for u in RepuestoOT.objects.filter(estado="usado").select_related("repuesto", "ot__equipo"):
        consumo[u.ot.equipo.nombre_habitual] += u.costo_total
    consumo = sorted(consumo.items(), key=lambda x: -x[1])[:5]
    return {
        "fallas": [(f["equipo__nombre_habitual"], f["n"]) for f in fallas],
        "consumo": consumo,
        "ot_abiertas": OrdenTrabajo.objects.exclude(estado="cerrada").count(),
        "ot_cerradas": OrdenTrabajo.objects.filter(estado="cerrada").count(),
        "stock_bajo": sum(1 for r in Repuesto.objects.all() if r.bajo_minimo),
    }


@rol_requerido(*PLANTA)
def informe_lista(request):
    informes = Informe.objects.select_related("autor")
    if request.user.perfil.rol == TECNICO:
        informes = informes.filter(compartido=True)
    ctx = {"informes": informes}
    if request.user.perfil.rol == INGENIERO:
        ctx["ind"] = _indicadores()
    return render(request, "mantenimiento/informe_lista.html", ctx)


@rol_requerido(*PLANTA)
def informe_detalle(request, pk):
    informe = get_object_or_404(Informe, pk=pk)
    if request.user.perfil.rol == TECNICO and not informe.compartido:
        raise Http404
    return render(request, "mantenimiento/informe_detalle.html", {"informe": informe})


@rol_requerido(INGENIERO)
def informe_nuevo(request):
    form = InformeForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        informe = form.save(commit=False)
        informe.autor = request.user
        informe.save()
        messages.success(request, "Informe guardado.")
        return redirect("informe_detalle", pk=informe.pk)
    return render(request, "mantenimiento/formulario.html", {"form": form, "titulo": "Nuevo informe", "boton": "Guardar informe"})


@require_POST
@rol_requerido(INGENIERO)
def informe_compartir(request, pk):
    informe = get_object_or_404(Informe, pk=pk)
    informe.compartido = not informe.compartido
    informe.save(update_fields=["compartido"])
    messages.success(request, "Informe compartido con los técnicos." if informe.compartido else "Informe dejado como privado.")
    return redirect("informe_detalle", pk=pk)


# ---------- Archivos subidos (solo con sesión iniciada) ----------
@login_required
def media(request, path):
    return servir_archivo(request, path, document_root=settings.MEDIA_ROOT)
