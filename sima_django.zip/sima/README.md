# SIMA · versión de planta (Django + PostgreSQL)

Prototipo funcional para **técnicos, ingenieros de mantenimiento y operarios** de Manufacturas Andina S.A.
La versión para administrativos y control de planta (JavaScript, HTML, CSS y Node.js) es un sistema aparte.

## Usuarios y qué ve cada uno

Solo se puede ingresar con correos **@manuandina.cl** y únicamente estos 3 usuarios existen:

| Correo | Clave inicial | Su interfaz |
|---|---|---|
| tecnico@manuandina.cl | Tecnico2026 | Avisos de falla, órdenes de trabajo con bitácora y traspaso, equipos con historial y manual, repuestos por bodega y tipo, notas y recomendaciones, informes compartidos |
| ingeniero@manuandina.cl | Ingeniero2026 | Todo lo anterior, más **planificador** (equipos de mantenimiento, optimización, preventivos), alertas de órdenes sin avance, indicadores e informes que se comparten con los técnicos |
| operador@manuandina.cl | Operador2026 | Menú simple: información de equipos, avisar una falla (con foto) y ver el estado de sus reportes |

Cambie las claves antes de usarlo de verdad (variables `SIMA_PASSWORD_*` en `.env`, o desde `/admin/` con un superusuario).

## Forma más fácil (Windows)

Instale Python (python.org, marcando "Add python.exe to PATH"), descomprima el zip y haga **doble clic en `iniciar.bat`**. Prepara todo y abre http://localhost:8000. Usa SQLite y `requirements-local.txt` (sin el conector de PostgreSQL); para PostgreSQL use Docker.

## Arrancar con Docker (PostgreSQL)

```bash
cp .env.example .env        # edite las claves y DJANGO_SECRET_KEY
docker compose up --build
```
Abra http://localhost:8000. Los datos quedan en PostgreSQL (volumen `pgdata`) y las fotos y manuales en el volumen `media`.

## Arrancar sin Docker

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
export POSTGRES_DB=sima POSTGRES_USER=sima POSTGRES_PASSWORD=sima_pass POSTGRES_HOST=localhost
python manage.py migrate
python manage.py seed_demo        # crea los 3 usuarios y datos de ejemplo
python manage.py runserver
```
Sin variables `POSTGRES_*` usa SQLite, solo para pruebas rápidas.

## Despliegue

- **Servidor propio o VPS:** `docker compose up -d --build` y un proxy con HTTPS delante (Caddy o Nginx) hacia el puerto 8000. Con dominio real use `DJANGO_HTTPS=1`, `DJANGO_ALLOWED_HOSTS` y `DJANGO_CSRF_TRUSTED_ORIGINS=https://su-dominio`.
- **Render:** suba el repositorio a GitHub y use *New > Blueprint* (usa `render.yaml`; crea la base PostgreSQL y el servicio web). Defina las 3 claves cuando lo pida.
- Para cargar el catálogo real de equipos y repuestos use `/admin/` (solo superusuarios: `python manage.py createsuperuser`).

## Pruebas

```bash
python manage.py test
```
Cubren el ingreso por dominio, permisos por rol, descuento de stock, bitácora inalterable y el flujo operador → técnico.

## Cómo responde a las historias de usuario

1. **Identificación de la máquina:** el operador elige la máquina por nombre habitual y lugar, adjunta foto, y ve el estado en *Mis reportes*.
2. **Historial antes de intervenir:** la ficha del equipo muestra las últimas 5 intervenciones con repuestos usados y el manual; botones grandes.
3. **Repuestos:** catálogo por bodega y tipo, stock mínimo, requerir o usar en una orden (descuenta stock y queda ligado a la orden y a la máquina), consumo por equipo en *Informes*.
4. **Continuidad entre turnos:** bitácora cronológica que no se edita ni se borra, nota de traspaso destacada, alerta a los 4 h sin avance en equipos críticos.
5. **Registro sin conexión:** **no incluido** en este prototipo (es la historia de mayor riesgo; se aborda en una siguiente iteración).

## Notas de seguridad

La sesión se cierra tras 30 minutos sin actividad (`SESSION_TIMEOUT_MIN`). Las fotos y manuales solo se descargan con sesión iniciada. En producción cambie `DJANGO_SECRET_KEY` y active `DJANGO_HTTPS=1`.
